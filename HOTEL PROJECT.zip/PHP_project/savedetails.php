
<html>
<head>
<title>Personal Details</title>
<h1>Personal Details</h1>

</head>
<body style="background-color:white;">
<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
<label for="First_Name">First name:</label><br>
<input name="First_Name" type="text" style=" margin-left: 0; margin-right: 1%; width: 20%; background-color:whitesmoke;"></style>
<label for="Last_name">Last name:</label>
<input  name="Last_Name"type="text" style="background-color:whitesmoke; width: 20%;"><br>
<label for="Email">Email Address:</label><br>
<input  name="Email" type="text" style="background-color:whitesmoke; width: 20%;"><br>
<label for="Mobile_number">Phone</label><br>
<input  name="Mobile_Number"type="text" style=" margin-left: 0; margin-right: 1%; width: 20%; background-color:whitesmoke;"></style><br>
<label for="Check_in">Arrival Date</label><br>
<input  name="Check_in"type="date" style="background-color:whitesmoke; width: 20%;"><br>
<label for="Check_out">Departure Date</label><br>
<input  name="Check_out" type="date" style="background-color:whitesmoke; width: 20%;"><br>

<label for="Members">Number of Members</label><br>
<input type="number" style="background-color:whitesmoke; width: 20%;"><br>


<p>GENDER</p>

<input type="radio" id="male" name="fav_language" value="male">
<label for="male">MALE</label><br>
<input type="radio" id="female" name="fav_language" value="female">
<label for="female">FEMALE</label><br>
<input type="radio" id="others" name="fav_language" value="others">
<label for="others">OTHERS</label><br>

<br>

<input type="submit" value="Submit">
</form>

</body>


<?php
// Include config file
require_once "config.php";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $input_First_Name = trim($_POST["First_Name"]);
    $First_Name = $input_First_Name;

    $input_Last_Name = trim($_POST["Last_Name"]);
    $Last_Name = $input_Last_Name;

    $input_Email = trim($_POST["Email"]);
    $Email = $input_Email;

    $input_Mobile_Number = trim($_POST["Mobile_Number"]);
    $Mobile_Number = $input_Mobile_Number;

    $input_Check_in = trim($_POST["Check_in"]);
    $Check_in = $input_Check_in;

    $input_Check_out = trim($_POST["Check_out"]);
    $Check_out = $input_Check_out;
    
    // Prepare an insert statement
    $sql = "INSERT INTO guest_details (First_Name, Last_Name, Email ,Mobile_Number,Check_in,Check_out) VALUES (?,?,?,?,?,?)";

    if ($stmt = mysqli_prepare($link, $sql)) {
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "sssiii", $param_First_Name, $param_Last_Name, $param_Email,$param_Mobile_Number,$param_Check_in,$param_Check_out);

        // Set parameters
        $param_First_Name = $First_Name;
        $param_Last_Name = $last_name;
        $param_Email = $Email;
        $param_Mobile_Number = $Mobile_Number;
        $param_Check_in = $Check_in;
        $param_Check_out = $Check_out;

        // Attempt to execute the prepared statement
        if (mysqli_stmt_execute($stmt)) {
            // Records created successfully. Redirect to landing page
            header("location: index.php");
            exit();
        } else {
            echo "Something went wrong. Please try again later.";
        }
    }

    // Close statement
    mysqli_stmt_close($stmt);

    // Close connection
    mysqli_close($link);
}
?>


