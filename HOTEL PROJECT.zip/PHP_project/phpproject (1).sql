-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2022 at 11:05 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `hotels`
--

CREATE TABLE `hotels` (
  `Sr_no` int(11) NOT NULL,
  `Hotel_Name` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `Rooms_Type` varchar(50) NOT NULL,
  `Star_Rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `hyatt`
--

CREATE TABLE `hyatt` (
  `Room_Type` varchar(50) NOT NULL,
  `Room_Number` varchar(50) NOT NULL,
  `Check_in` date NOT NULL,
  `Check_out` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `hyatt_roombook`
--

CREATE TABLE `hyatt_roombook` (
  `id` int(10) UNSIGNED NOT NULL,
  `Title` varchar(5) DEFAULT NULL,
  `FName` text DEFAULT NULL,
  `LName` text DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `National` varchar(30) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL,
  `Phone` text DEFAULT NULL,
  `TRoom` varchar(20) DEFAULT NULL,
  `Bed` varchar(10) DEFAULT NULL,
  `NRoom` varchar(2) DEFAULT NULL,
  `Meal` varchar(15) DEFAULT NULL,
  `cin` date DEFAULT NULL,
  `cout` date DEFAULT NULL,
  `stat` varchar(15) DEFAULT NULL,
  `nodays` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hyatt_roombook`
--

INSERT INTO `hyatt_roombook` (`id`, `Title`, `FName`, `LName`, `Email`, `National`, `Country`, `Phone`, `TRoom`, `Bed`, `NRoom`, `Meal`, `cin`, `cout`, `stat`, `nodays`) VALUES
(2, 'Mr.', 'Vansh', 'Shah', 'vanshsha0112@gmail.com', 'NPLE', 'Finland', '+3581234567891', 'Deluxe Room', 'Triple', '1', 'Half Board', '2022-05-26', '2022-05-27', 'Not Conform', 1),
(3, 'Mr.', 'Vansh', 'Shah', 'vanshshah011@gmail.com', 'NPLE', 'Finland', '+3581234567891', 'Superior Room', 'Double', '1', 'Full Board', '2022-06-23', '2022-06-17', 'Not Conform', -6),
(4, 'Prof.', 'Vansh', 'Shah', 'vanshshah02432@gmail.com', 'NPLE', 'Finland', '+3581234567891', 'Guest House', 'Triple', '1', 'Room only', '2022-06-29', '2022-06-30', 'Not Conform', 1);

-- --------------------------------------------------------

--
-- Table structure for table `marriot_roombook`
--

CREATE TABLE `marriot_roombook` (
  `id` int(10) UNSIGNED NOT NULL,
  `Title` varchar(5) DEFAULT NULL,
  `FName` text DEFAULT NULL,
  `LName` text DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `National` varchar(30) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL,
  `Phone` text DEFAULT NULL,
  `TRoom` varchar(20) DEFAULT NULL,
  `Bed` varchar(10) DEFAULT NULL,
  `NRoom` varchar(2) DEFAULT NULL,
  `Meal` varchar(15) DEFAULT NULL,
  `cin` date DEFAULT NULL,
  `cout` date DEFAULT NULL,
  `stat` varchar(15) DEFAULT NULL,
  `nodays` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marriot_roombook`
--

INSERT INTO `marriot_roombook` (`id`, `Title`, `FName`, `LName`, `Email`, `National`, `Country`, `Phone`, `TRoom`, `Bed`, `NRoom`, `Meal`, `cin`, `cout`, `stat`, `nodays`) VALUES
(1, 'Dr.', 'jay', 'singh', 'jay09@gmail.com', 'NPLE', 'Australia', '+3581234567891', 'Guest House', 'Triple', '1', 'Full Board', '2022-06-29', '2022-06-30', 'Not Conform', 1),
(2, 'Prof.', 'deepak', 'acharya', 'deepakc12@gmail.com', 'NPLE', 'India', '+9181234567891', 'Guest House', 'Single', '1', 'Half Board', '2022-06-30', '2022-07-01', 'Not Conform', 1);

-- --------------------------------------------------------

--
-- Table structure for table `novotel`
--

CREATE TABLE `novotel` (
  `Room_Type` varchar(50) NOT NULL,
  `Room_Number` varchar(50) NOT NULL,
  `Check_in` date NOT NULL,
  `Check_out` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `novottel_roombook`
--

CREATE TABLE `novottel_roombook` (
  `id` int(10) UNSIGNED NOT NULL,
  `Title` varchar(5) DEFAULT NULL,
  `FName` text DEFAULT NULL,
  `LName` text DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `National` varchar(30) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL,
  `Phone` text DEFAULT NULL,
  `TRoom` varchar(20) DEFAULT NULL,
  `Bed` varchar(10) DEFAULT NULL,
  `NRoom` varchar(2) DEFAULT NULL,
  `Meal` varchar(15) DEFAULT NULL,
  `cin` date DEFAULT NULL,
  `cout` date DEFAULT NULL,
  `stat` varchar(15) DEFAULT NULL,
  `nodays` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `novottel_roombook`
--

INSERT INTO `novottel_roombook` (`id`, `Title`, `FName`, `LName`, `Email`, `National`, `Country`, `Phone`, `TRoom`, `Bed`, `NRoom`, `Meal`, `cin`, `cout`, `stat`, `nodays`) VALUES
(1, 'Mr.', 'Vansh', 'Shah', 'vanshshah0112@gmail.com', 'NPLE', 'Finland', '+3581234567891', 'King Room', 'Quad', '1', 'Half Board', '2022-06-21', '2022-06-30', 'Not Conform', 9),
(2, 'Mr.', 'pritesh', 'parmar', 'pkp123@gmail.com', 'NPLE', 'Austria', '35437891', 'Superior Room', 'Quad', '1', 'Half Board', '2022-06-28', '2022-07-06', 'Not Conform', 8);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(15) DEFAULT NULL,
  `bedding` varchar(10) DEFAULT NULL,
  `place` varchar(10) DEFAULT NULL,
  `cusid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `type`, `bedding`, `place`, `cusid`) VALUES
(1, 'Superior Room', 'Single', 'Free', NULL),
(2, 'Superior Room', 'Double', 'Free', NULL),
(3, 'Superior Room', 'Triple', 'Free', NULL),
(4, 'Premier Room', 'Quad', 'Free', NULL),
(5, 'Superior Room', 'Quad', 'Free', NULL),
(6, 'King Room', 'Single', 'Free', NULL),
(7, 'King Room', 'Double', 'Free', NULL),
(8, 'King Room', 'Triple', 'Free', NULL),
(9, 'King Room', 'Quad', 'Free', NULL),
(10, 'Premier Room', 'Single', 'Free', NULL),
(11, 'Premier Room', 'Double', 'Free', NULL),
(12, 'Premier Room', 'Triple', 'Free', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `taj_roombook`
--

CREATE TABLE `taj_roombook` (
  `id` int(10) UNSIGNED NOT NULL,
  `Title` varchar(5) DEFAULT NULL,
  `FName` text DEFAULT NULL,
  `LName` text DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `National` varchar(30) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL,
  `Phone` text DEFAULT NULL,
  `TRoom` varchar(20) DEFAULT NULL,
  `Bed` varchar(10) DEFAULT NULL,
  `NRoom` varchar(2) DEFAULT NULL,
  `Meal` varchar(15) DEFAULT NULL,
  `cin` date DEFAULT NULL,
  `cout` date DEFAULT NULL,
  `stat` varchar(15) DEFAULT NULL,
  `nodays` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taj_roombook`
--

INSERT INTO `taj_roombook` (`id`, `Title`, `FName`, `LName`, `Email`, `National`, `Country`, `Phone`, `TRoom`, `Bed`, `NRoom`, `Meal`, `cin`, `cout`, `stat`, `nodays`) VALUES
(1, 'Rev .', 'Vansh', 'Shah', 'vanshshah0112@gmail.com', 'NPLE', 'Finland', '+3581234567891', 'King Room', 'Quad', '1', 'Breakfast', '2022-06-23', '2022-06-30', 'Not Conform', 7),
(2, 'Mr.', 'raj', 'Shah', 'raj12@gmail.com', 'NPLE', 'Finland', '+3581234567891', 'King Room', 'Double', '1', 'Breakfast', '2022-06-27', '2022-06-30', 'Not Conform', 3),
(3, 'Mr.', 'kevin', 'thakkar', 'kt12@gmail.com', 'NPLE', 'Finland', '+3581234567891', 'King Room', 'Double', '1', 'Breakfast', '2022-06-23', '2022-06-30', 'Not Conform', 7),
(4, 'Rev .', 'Vansh', 'patel', 'vanshpatel011111@gmail.com', 'NPLE', 'Finland', '+3581234567891', 'Premier Room', 'Triple', '1', 'Breakfast', '2022-06-24', '2022-06-29', 'Not Conform', 5),
(5, 'Mr.', 'viraj', 'shah', 'vs324@gmail.com', 'NPLE', 'India', '+919898983212', 'Superior Room', 'Double', '1', 'Breakfast', '2022-06-30', '2022-07-04', 'Not Conform', 4),
(6, 'Mr.', 'rajesh', 'patel', 'rp24@gmail.com', 'NPLE', 'India', '+919429088601', 'King Room', 'Triple', '1', 'Breakfast', '2022-06-15', '2022-06-21', 'Not Conform', 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hotels`
--
ALTER TABLE `hotels`
  ADD PRIMARY KEY (`Sr_no`);

--
-- Indexes for table `hyatt_roombook`
--
ALTER TABLE `hyatt_roombook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `marriot_roombook`
--
ALTER TABLE `marriot_roombook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `novottel_roombook`
--
ALTER TABLE `novottel_roombook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `taj_roombook`
--
ALTER TABLE `taj_roombook`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hotels`
--
ALTER TABLE `hotels`
  MODIFY `Sr_no` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hyatt_roombook`
--
ALTER TABLE `hyatt_roombook`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `marriot_roombook`
--
ALTER TABLE `marriot_roombook`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `novottel_roombook`
--
ALTER TABLE `novottel_roombook`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `taj_roombook`
--
ALTER TABLE `taj_roombook`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
