<!DOCTYPE html>
 <html class="no-js"> 
	<head>
		<title>Hotel Management Services</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">

<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	

 
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	
	<link rel="shortcut icon" href="favicon.ico">
	
	<link rel="stylesheet" href="css/superfish.css">
	
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	
	<link rel="stylesheet" href="css/cs-select.css">

	<link rel="stylesheet" href="css/cs-skin-border.css">

	<link rel="stylesheet" href="css/themify-icons.css">
	
	<link rel="stylesheet" href="css/flaticon.css">
	
	<link rel="stylesheet" href="css/icomoon.css">
	
	<link rel="stylesheet" href="css/flexslider.css">
	
	<link rel="stylesheet" href="css/style.css">
	
	<script src="js/modernizr-2.6.2.min.js"></script>
	
<style>
	
	nav {
	background: linear-gradient(-50deg, #ee7752, #FFD700, #23a6d5, #8A6E2F);
	background-size: 400% 400%;
  color: white;
	animation: gradient 3s ease-in-out infinite;
	height: 10vh;
  font-size: 20px;
  background-color: red; /* For browsers that do not support gradients */
  display : block;
  position: relative;
  overflow: hidden;
  align-items: center;
  z-index: 10;
  justify-content: right;
  bottom: 0;
}


@keyframes gradient {
	0% {
		background-position: 0% 50%;
	}
	50% {
		background-position: 100% 50%;
	}
	100% {
		background-position: 0% 50%;
	}
}
    nav ul  li{
    
    display: inline-block ;
    
    /* align-items: center; */
    color: blueviolet;
    /* text-align: center; */
    padding: 14px 16px;
    font-size: 20px; 
    font-family: "Sofia",sans-serif ;
    z-index: 10; 
}
.hname{
  background-color: #e6e6e6;
}
  
  .header1 a:hover {
    
    background-color: aqua;
    color: blueviolet;
  }
  
  .header1 a.active {
    color: blueviolet;
    
  }
  * {
  box-sizing: border-box;
}

/* Create three equal columns that floats next to each other */
.column {
  float: left;
  width: 33.33%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
.dropbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
  width: 300px;
}

.dropdown-content {
  display: none;
  position: absolute;
  bottom: 100%;
  background-color: #f1f1f1;
  min-width: 100px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
.content{
          font-size: 20px;
          font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
          word-spacing: 4px;
}
.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>
</head>
<body>
	<div class="header1">
	<nav>
			<ul>
				<li><a href="main.php" style="text-decoration: none";>HOME</a></li>
				<li><a href="TAJ1.php" style="text-decoration: none;" >TAJ HOTELS</a></li>
				<li><a href="MARRIOT1.php" style="text-decoration: none;">MARRIOT BANVOY HOTELS</a></li>
				<li><a href="novotel.php" style="text-decoration: none;">NOVOTEL HOTELS</a></li>
				<li><a href="HAYATT1.php" style="text-decoration: none;">HAYATT HOTELS</a></li>
				<li><a href="contact.htm" style="text-decoration: none;">CONTACT US</a></li>
			</ul>
			
		</nav>
		<div class="hname">
		
			<h1>NOVOTEL BANGALORE</h1>
			<p><i class="material-icons">&#xe55f;</i> Opp Rmz Ecospace Business Park Marthahalli, Sarjapur - Marathahalli Rd, Bengaluru, Karnataka 560103</p>
		
		</div>
	
		<div id="featured-hotel" class="fh5co-bg-color">
			<div class="container">
				
				<div class="row">
					<div class="col-md-12">
						<div class="section-title text-center">
							<h2>Featured Rooms</h2>
						</div>
					</div>
				</div>
	
				<div class="row">
					<div class="feature-full-1col">
						<div class="image" style="background-image: url(n3.webp);">
							<div class="descrip text-center">
								<p><small>For as low as</small><span>$199/night</span></p>
							</div>
						</div>
						<div class="desc">
							<h3>SUPERIOR ROOM</h3>
							<p> A superior is best room among all rooms in hotels it is too costly because it  covers a large area of room, it is comfortable or has better amenities than other rooms. Superior rooms have a beautiful view over the hills. The superior rooms are larger than the king rooms.</p>
							<p><a href="novottel_reservation.php" class="btn btn-primary btn-luxe-primary">Book Now <i class="ti-angle-right"></i></a></p>
						</div>
					</div>
	
					<div class="feature-full-2col">
						<div class="f-hotel">
							<div class="image" style="background-image: url(n3.jpg);">
								<div class="descrip text-center">
									<p><small>For as low as</small><span>$99/night</span></p>
								</div>
							</div>
							<div class="desc">
								<h3>KING ROOM</h3>
								<p>The King suite comes with a king bed, for those who would like some extra space. A few rooms have enough floor space to fit a third bed, should this be required, such as if traveling with a child. The bathrooms are lined with natural stone that sparkles in the light.</p>
								<p><a href="novottel_reservation.php" class="btn btn-primary btn-luxe-primary">Book Now <i class="ti-angle-right"></i></a></p>
							</div>
						</div>
						<div class="f-hotel">
							<div class="image" style="background-image: url(n2.jpg);">
								<div class="descrip text-center">
									<p><small>For as low as</small><span>$49/night</span></p>
								</div>
							</div>
							<div class="desc">
								<h3>PREIMER ROOM</h3>
								<p>Premier Rooms offer a lavish yet comfortable ambience to relax in after a hectic day of sightseeing or meetings. Fitted with a king bed, the rooms are spacious with warm wooden flooring, soft lighting and five star amenities.
	
	 </p>
								<p><a href="novottel_reservation.php" class="btn btn-primary btn-luxe-primary">Book Now <i class="ti-angle-right"></i></a></p>
							</div>
						</div>
					</div>
				</div>
	
			</div>
		</div>
	
	<div id="hotel-facilities">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="section-title text-center">
						<h2>Hotel Facilities</h2>
					</div>
				</div>
			</div>

			<div id="tabs">
				<nav class="tabs-nav">
					<a href="#" class="active" data-tab="tab1">
						<i class="flaticon-restaurant icon"></i>
						<span>Restaurant</span>
					</a>
					<a href="#" data-tab="tab2">
						<i class="flaticon-cup icon"></i>
						<span>Bar</span>
					</a>
					<a href="#" data-tab="tab3">
					
						<i class="flaticon-car icon"></i>
						<span>Pick-up</span>
					</a>
					<a href="#" data-tab="tab4">
						
						<i class="flaticon-swimming icon"></i>
						<span>Swimming Pool</span>
					</a>
					<a href="#" data-tab="tab5">
						
						<i class="flaticon-massage icon"></i>
						<span>Spa</span>
					</a>
					<a href="#" data-tab="tab6">
						
						<i class="flaticon-bicycle icon"></i>
						<span>Gym</span>
					</a>
				</nav>
				<div class="tab-content-container">
					<div class="tab-content active show" data-tab-content="tab1">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="novotelrestaurant.jpg" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">World Class</span>
									<h3 class="heading">Restaurant</h3>
									<p>At Novotel, we believe that quality time is about making everyday moments matter. Everything has been thought to enhance our guests’ life balance, sense of well being but also enjoyment. Whether through our intuitive & modern design or our large range of rewarding experiences, everyone can disconnect from a busy life or make time to connect with their family, friends or colleagues. This combination makes Novotel the perfect spot for travellers and locals to have a drink, a bite to eat, to work, play or just relax.
										novotel is best. To rest and relax - for you or your loved ones, to refresh, reset and feel good. Novotel Gym includes standard excersice machine,and the food quality is too good.</p>
									<p class="service-hour">
										<span>Service Hours</span>
										<strong>7:30 AM - 8:00 PM</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab2">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="novotelbars.webp" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">World Class</span>
									<h3 class="heading">Bars</h3>
									<p>At Novotel, we believe that quality time is about making everyday moments matter. Everything has been thought to enhance our guests’ life balance, sense of well being but also enjoyment. Whether through our intuitive & modern design or our large range of rewarding experiences, everyone can disconnect from a busy life or make time to connect with their family, friends or colleagues. This combination makes Novotel the perfect spot for travellers and locals to have a drink, a bite to eat, to work, play or just relax.
										novotel is best. To rest and relax - for you or your loved ones, to refresh, reset and feel good. Novotel Gym includes standard excersice machine,and the food quality is too good.</p>
									<p class="service-hour">
										<span>Service Hours</span>
										<strong>7:30 AM - 8:00 PM</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab3">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="img/novotelpickup.jpg" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">World Class</span>
									<h3 class="heading">Pick Up</h3>
									<p>At Novotel, we believe that quality time is about making everyday moments matter. Everything has been thought to enhance our guests’ life balance, sense of well being but also enjoyment. Whether through our intuitive & modern design or our large range of rewarding experiences, everyone can disconnect from a busy life or make time to connect with their family, friends or colleagues. This combination makes Novotel the perfect spot for travellers and locals to have a drink, a bite to eat, to work, play or just relax.
										novotel is best. To rest and relax - for you or your loved ones, to refresh, reset and feel good. Novotel Gym includes standard excersice machine,and the food quality is too good.</p>
									<p class="service-hour">
										<span>Service Hours</span>
										<strong>7:30 AM - 8:00 PM</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab4">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="novotelswimmingpool.jpg" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">World Class</span>
									<h3 class="heading">Swimming Pool</h3>
									<p>At Novotel, we believe that quality time is about making everyday moments matter. Everything has been thought to enhance our guests’ life balance, sense of well being but also enjoyment. Whether through our intuitive & modern design or our large range of rewarding experiences, everyone can disconnect from a busy life or make time to connect with their family, friends or colleagues. This combination makes Novotel the perfect spot for travellers and locals to have a drink, a bite to eat, to work, play or just relax.
										novotel is best. To rest and relax - for you or your loved ones, to refresh, reset and feel good. Novotel Gym includes standard excersice machine,and the food quality is too good.</p>
									<p class="service-hour">
										<span>Service Hours</span>
										<strong>7:30 AM - 8:00 PM</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab5">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="novotelSPA.jpg" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">World Class</span>
									<h3 class="heading">Spa</h3>
									<p>At Novotel, we believe that quality time is about making everyday moments matter. Everything has been thought to enhance our guests’ life balance, sense of well being but also enjoyment. Whether through our intuitive & modern design or our large range of rewarding experiences, everyone can disconnect from a busy life or make time to connect with their family, friends or colleagues. This combination makes Novotel the perfect spot for travellers and locals to have a drink, a bite to eat, to work, play or just relax.
										novotel is best. To rest and relax - for you or your loved ones, to refresh, reset and feel good. Novotel Gym includes standard excersice machine,and the food quality is too good.</p>
									<p class="service-hour">
										<span>Service Hours</span>
										<strong>7:30 AM - 8:00 PM</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab6">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="novotelGYM.jpg" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">World Class</span>
									<h3 class="heading">Gym</h3>
									<p>At Novotel, we believe that quality time is about making everyday moments matter. Everything has been thought to enhance our guests’ life balance, sense of well being but also enjoyment. Whether through our intuitive & modern design or our large range of rewarding experiences, everyone can disconnect from a busy life or make time to connect with their family, friends or colleagues. This combination makes Novotel the perfect spot for travellers and locals to have a drink, a bite to eat, to work, play or just relax.
										novotel is best. To rest and relax - for you or your loved ones, to refresh, reset and feel good. Novotel Gym includes standard excersice machine,and the food quality is too good.</p>
									<p class="service-hour">
										<span>Service Hours</span>
										<strong>7:30 AM - 8:00 PM</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
	
	<script src="js/jquery-2.1.4.min.js"></script>
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.countTo.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/bootstrap-datepicker.min.js"></script>
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	<script src="js/jquery.flexslider-min.js"></script>
	<script src="js/custom.js"></script>

</body>
</html>