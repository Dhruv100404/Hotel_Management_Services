<html>
    <html lang="en">
<head>
<title>Hotel Management Services</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
    nav {
	background: linear-gradient(-50deg, #ee7752, #FFD700, #23a6d5, #8A6E2F);
	background-size: 400% 400%;
  color: white;
	animation: gradient 3s ease-in-out infinite;
	height: 10vh;
  font-size: 20px;
  background-color: red; /* For browsers that do not support gradients */
  display : block;
  position: relative;
  overflow: hidden;
  align-items: center;
  z-index: 10;
  justify-content: right;
  bottom: 0;
}

@keyframes gradient {
	0% {
		background-position: 0% 50%;
	}
	50% {
		background-position: 100% 50%;
	}
	100% {
		background-position: 0% 50%;
	}
}
    nav ul  li{
    
    display: inline-block ;
    
    /* align-items: center; */
    color: white;
    /* text-align: center; */
    padding: 14px 16px;
    font-size: 20px; 
    font-family: "Sofia",sans-serif ;
    z-index: 10; 
}

  
  .header1 a:hover {
    
    background-color: aqua;
    color: white;
  }
  
  .header1 a.active {
    color: white;
    
  }

  </style>

<style>
 
  
  
 @import url("https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900");

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}

body {
 
  background: aquamarine;
  min-width: 100vh;
  
}

.content {
  position: center;
}

.content h1 {
  color: #fff;
  font-size: 80px;
  position: absolute;
  margin-left: 500px;
  margin-top: 200px;
  align-items: center;
  justify-content: center;
  transform: translate(-50%, -50%);
}

.content h1:nth-child(1) {
  color: transparent;
  -webkit-text-stroke: 3px #03a9f4;
}

.content h1:nth-child(2) {
  color: #03a9f4;
  animation: animate 2s ease-in-out infinite;
}

@keyframes animate {
  0%,
  100% {
    clip-path: polygon(
      0% 45%,
      20% 35%,
      45% 60%,
      54% 60%,
      70% 61%,
      0% 100%
    );
  }

  50% {
    clip-path: polygon(
      0% 60%,
      15% 65%,
      34% 66%,
      84% 45%,
      100% 46%,
      100% 100%,
      0% 100%
    );
  }
}
 

  </style>
</head>
<body>
    <div class="header1">
    <nav>
        <ul>
            <li><a href="main.php" style="text-decoration: none;" >HOME</a></li>
            <li><a href="TAJ1.php" style="text-decoration: none;" >TAJ HOTELS</a></li>
            <li><a href="MARRIOT1.php" style="text-decoration: none;">MARRIOT BANVOY HOTELS</a></li>
            <li><a href="novotel.php" style="text-decoration: none;">NOVOTEL HOTELS</a></li>
            <li><a href="HAYATT1.php" style="text-decoration: none;">HAYATT HOTELS</a></li>
            <li><a href="contact.htm" style="text-decoration: none;">CONTACT US</a></li>
        </ul>

        
    </nav>
</div>
<section>
<div class="content">

 <h1>WELCOME TO<br> TRAVELHOLICS</h1>
 <h1>WELCOME TO <br>TRAVELHOLICS</h1>   
  <br>
  <br> 
    <h1>THE BEST PLACE FOR THE LUXURY STAY</h1>
    <h1>THE BEST PLACE FOR THE LUXURY STAY</h1>
  </div>
</section>


</body>
</html>