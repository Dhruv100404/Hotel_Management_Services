<!DOCTYPE html>
 <html class="no-js"> 
	<head>
		<title>Hotel Management Services</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">

<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	

 
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	
	<link rel="shortcut icon" href="favicon.ico">
	
	<link rel="stylesheet" href="css/superfish.css">
	
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	
	<link rel="stylesheet" href="css/cs-select.css">

	<link rel="stylesheet" href="css/cs-skin-border.css">

	<link rel="stylesheet" href="css/themify-icons.css">
	
	<link rel="stylesheet" href="css/flaticon.css">
	
	<link rel="stylesheet" href="css/icomoon.css">
	
	<link rel="stylesheet" href="css/flexslider.css">
	
	<link rel="stylesheet" href="css/style.css">
	
	<script src="js/modernizr-2.6.2.min.js"></script>
	
<style>
	
	nav {
	background: linear-gradient(-50deg, #ee7752, #FFD700, #23a6d5, #8A6E2F);
	background-size: 400% 400%;
    color: white;
	animation: gradient 3s ease-in-out infinite;
	height: 10vh;
    font-size: 20px;
    background-color: red; /* For browsers that do not support gradients */
    display : block;
    position: relative;
    overflow: hidden;
    align-items: center;
    z-index: 10;
    justify-content: right;
    bottom: 0;
}

@keyframes gradient {
	0% {
		background-position: 0% 50%;
	}
	50% {
		background-position: 100% 50%;
	}
	100% {
		background-position: 0% 50%;
	}
}
    nav ul  li{
    
    display: inline-block ;
    
    /* align-items: center; */
    color: blueviolet;
    /* text-align: center; */
    padding: 14px 16px;
    font-size: 20px; 
    font-family: "Sofia",sans-serif ;
    z-index: 10; 
}
.hname{
  background-color: #e6e6e6;
}
  
  .header1 a:hover {
    
    background-color: aqua;
    color: blueviolet;
  }
  
  .header1 a.active {
    color: blueviolet;
    
  }
  * {
  box-sizing: border-box;
}

/* Create three equal columns that floats next to each other */
.column {
  float: left;
  width: 33.33%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
.dropbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
  width: 300px;
}

.dropdown-content {
  display: none;
  position: absolute;
  bottom: 100%;
  background-color: #f1f1f1;
  min-width: 100px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
.content{
          font-size: 20px;
          font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
          word-spacing: 4px;
}
.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>
</head>
<body>
	<div class="header1">
	<nav>
			<ul>
				<li><a href="main.php" style="text-decoration: none";>HOME</a></li>
				<li><a href="TAJ1.php" style="text-decoration: none;" >TAJ HOTELS</a></li>
				<li><a href="MARRIOT1.php" style="text-decoration: none;">MARRIOT BANVOY HOTELS</a></li>
				<li><a href="novotel.php" style="text-decoration: none;">NOVOTEL HOTELS</a></li>
				<li><a href="HAYATT1.php" style="text-decoration: none;">HAYATT HOTELS</a></li>
				<li><a href="contact.htm" style="text-decoration: none;">CONTACT US</a></li>
			</ul>
			
		</nav>
			
		</nav>
		<div class="hname">
		
			<h1>HYATT AHMEDABAD</h1>
			<p><i class="material-icons">&#xe55f;</i> 17/A Ashram Road, Ahmedabad, Gujarat 380014</p>
		
		</div>
	
	<div id="featured-hotel" class="fh5co-bg-color">
		<div class="container">
			
			<div class="row">
				<div class="col-md-12">
					<div class="section-title text-center">
						<h2>Featured Rooms</h2>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="feature-full-1col">
					<div class="image" style="background-image: url(img1.webp);">
						<div class="descrip text-center">
							<p><small>For as low as</small><span>$199/night</span></p>
						</div>
					</div>
					<div class="desc">
						<h3>SUPERIOR ROOM</h3>
						<p>Entertain in a spacious 150-square-metre one bedroom suite on the Regency Club floor, 
							well appointed in luxury western style.  The suite features designer furniture,
							 spacious living room, kitchen, dining room, walk-in closet, king-size bed, spacious
							  italian bathroom with a bathtub, rain shower and an exclusive powder room for your guests.
							 Maximum guests per room: 3 This is a premium suite. See World of Hyatt program terms for upgrade eligibility.</p>
						<p><a href="hyatt_reservation.php" class="btn btn-primary btn-luxe-primary">Book Now <i class="ti-angle-right"></i></a></p>
					</div>
				</div>

				<div class="feature-full-2col">
					<div class="f-hotel">
						<div class="image" style="background-image: url(img2.jpg);">
							<div class="descrip text-center">
								<p><small>For as low as</small><span>$99/night</span></p>
							</div>
						</div>
						<div class="desc">
							<h3>KING ROOM</h3>
							<p>Magnificent views of Sabarmati river welcome you to a spacious 100-square-metre suite
								offering living area, kitchenette, king bedroom with a bathtub and a rain shower.Along with this you can experience mesmerising property of Hyatt. 
								Maximum guests per room: 3 This is a premium suite.  </p>
							<p><a href="hyatt_reservation.php" class="btn btn-primary btn-luxe-primary">Book Now <i class="ti-angle-right"></i></a></p>
						</div>
					</div>
					<div class="f-hotel">
						<div class="image" style="background-image: url(img11.webp);">
							<div class="descrip text-center">
								<p><small>For as low as</small><span>$49/night</span></p>
							</div>
						</div>
						<div class="desc">
							<h3>PREIMER ROOM</h3>
							<p>A sophisticated 80 sq m suite with king bed, separate living area, walk-in wardrobe,
								and deluxe bathroom with soaking tub, rain shower, double vanity and glass shower 
								cubical. The suite features contemporary interiors with beautiful artefacts, designer 
								furniture, and interiors in pastel shades.   . </p>
							<p><a href="hyatt_reservation.php" class="btn btn-primary btn-luxe-primary">Book Now <i class="ti-angle-right"></i></a></p>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>

	<div id="hotel-facilities">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="section-title text-center">
						<h2>Hotel Facilities</h2>
					</div>
				</div>
			</div>

			<div id="tabs">
				<nav class="tabs-nav">
					<a href="#" class="active" data-tab="tab1">
						<i class="flaticon-restaurant icon"></i>
						<span>Restaurant</span>
					</a>
					<a href="#" data-tab="tab2">
						<i class="flaticon-cup icon"></i>
						<span>Bar</span>
					</a>
					<a href="#" data-tab="tab3">
					
						<i class="flaticon-car icon"></i>
						<span>Pick-up</span>
					</a>
					<a href="#" data-tab="tab4">
						
						<i class="flaticon-swimming icon"></i>
						<span>Swimming Pool</span>
					</a>
					<a href="#" data-tab="tab5">
						
						<i class="flaticon-massage icon"></i>
						<span>Spa</span>
					</a>
					<a href="#" data-tab="tab6">
						
						<i class="flaticon-bicycle icon"></i>
						<span>Gym</span>
					</a>
				</nav>
				<div class="tab-content-container">
					<div class="tab-content active show" data-tab-content="tab1">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="hyattresturant.webp" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">World Class</span>
									<h3 class="heading">Restaurant</h3>
									<p>HayattHotels is a chain of luxury hotels and a subsidiary of the Indian Hotels Company Limited.The company employed over 20,000 people in the year 2010.

										As of 2020, the company operates a total of 100 plus hotels and hotel-resorts, with 84 across India and 16 in other countries, including Bhutan, Malaysia, Maldives, Nepal, South Africa, Sri Lanka, UAE, UK, USA and Zambia.
										
										hayatt hotel includes many things like resturant, GYM and for swimming it can provide wide pool, pick up vahicle and bars etc..</p>
									<p class="service-hour">
										<span>Service Hours</span>
										<strong>7:30 AM - 8:00 PM</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab2">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="hyattbars.webp" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">World Class</span>
									<h3 class="heading">Bars</h3>
									<p>HayattHotels is a chain of luxury hotels and a subsidiary of the Indian Hotels Company Limited.The company employed over 20,000 people in the year 2010.

										As of 2020, the company operates a total of 100 plus hotels and hotel-resorts, with 84 across India and 16 in other countries, including Bhutan, Malaysia, Maldives, Nepal, South Africa, Sri Lanka, UAE, UK, USA and Zambia.
										
										hayatt hotel includes many things like resturant, GYM and for swimming it can provide wide pool, pick up vahicle and bars etc..</p>
									<p class="service-hour">
										<span>Service Hours</span>
										<strong>7:30 AM - 8:00 PM</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab3">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="hyattpickup.webp" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">World Class</span>
									<h3 class="heading">Pick Up</h3>
									<p>HayattHotels is a chain of luxury hotels and a subsidiary of the Indian Hotels Company Limited.The company employed over 20,000 people in the year 2010.

										As of 2020, the company operates a total of 100 plus hotels and hotel-resorts, with 84 across India and 16 in other countries, including Bhutan, Malaysia, Maldives, Nepal, South Africa, Sri Lanka, UAE, UK, USA and Zambia.
										
										hayatt hotel includes many things like resturant, GYM and for swimming it can provide wide pool, pick up vahicle and bars etc..</p>
									<p class="service-hour">
										<span>Service Hours</span>
										<strong>7:30 AM - 8:00 PM</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab4">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="hyattswimmingpool.webp" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">World Class</span>
									<h3 class="heading">Swimming Pool</h3>
									<p>HayattHotels is a chain of luxury hotels and a subsidiary of the Indian Hotels Company Limited.The company employed over 20,000 people in the year 2010.

										As of 2020, the company operates a total of 100 plus hotels and hotel-resorts, with 84 across India and 16 in other countries, including Bhutan, Malaysia, Maldives, Nepal, South Africa, Sri Lanka, UAE, UK, USA and Zambia.
										
										hayatt hotel includes many things like resturant, GYM and for swimming it can provide wide pool, pick up vahicle and bars etc..</p>
									<p class="service-hour">
										<span>Service Hours</span>
										<strong>7:30 AM - 8:00 PM</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab5">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="hyattSPM.jpg" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">World Class</span>
									<h3 class="heading">Spa</h3>
									<p>HayattHotels is a chain of luxury hotels and a subsidiary of the Indian Hotels Company Limited.The company employed over 20,000 people in the year 2010.

										As of 2020, the company operates a total of 100 plus hotels and hotel-resorts, with 84 across India and 16 in other countries, including Bhutan, Malaysia, Maldives, Nepal, South Africa, Sri Lanka, UAE, UK, USA and Zambia.
										
										hayatt hotel includes many things like resturant, GYM and for swimming it can provide wide pool, pick up vahicle and bars etc..</p>
									<p class="service-hour">
										<span>Service Hours</span>
										<strong>7:30 AM - 8:00 PM</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-content" data-tab-content="tab6">
						<div class="container">
							<div class="row">
								<div class="col-md-6">
									<img src="hyattGYM.jpg" class="img-responsive" alt="Image">
								</div>
								<div class="col-md-6">
									<span class="super-heading-sm">World Class</span>
									<h3 class="heading">Gym</h3>
									<p>HayattHotels is a chain of luxury hotels and a subsidiary of the Indian Hotels Company Limited.The company employed over 20,000 people in the year 2010.

										As of 2020, the company operates a total of 100 plus hotels and hotel-resorts, with 84 across India and 16 in other countries, including Bhutan, Malaysia, Maldives, Nepal, South Africa, Sri Lanka, UAE, UK, USA and Zambia.
										
										hayatt hotel includes many things like resturant, GYM and for swimming it can provide wide pool, pick up vahicle and bars etc..</p>
									<p class="service-hour">
										<span>Service Hours</span>
										<strong>7:30 AM - 8:00 PM</strong>
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
	
	<script src="js/jquery-2.1.4.min.js"></script>
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.countTo.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/bootstrap-datepicker.min.js"></script>
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	<script src="js/jquery.flexslider-min.js"></script>
	<script src="js/custom.js"></script>

</body>
</html>